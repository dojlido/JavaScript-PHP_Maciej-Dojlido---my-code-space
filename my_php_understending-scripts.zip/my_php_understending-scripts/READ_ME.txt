Dear Reader,
 

 
Files below are a presentation of some part of my work and my teaching process which is in a constant progress. In some file I put comments, which are to show my method of work and my way of thinking. As I sayed I will gradually add new samples of my skills and knowledge.
 
PHP files presents only part of my work in this programming language. 

If you want to find my website You can use the browser and by the phrase "maciej dojlido" you will find my first non-commercial project. I am conscius,that it contains some mistakes which I will remove as fast as I will find time.

I hope it will be a good introduction to common partnership.
 
Thanks for your attention.
 

 
 
email adress : maciej.dojlido@gmail.com