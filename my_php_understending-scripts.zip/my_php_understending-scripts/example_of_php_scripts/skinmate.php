<?php
$baza=mysqli_connect("localhost","root","haslo","skinmate");

if (mysqli_connect_errno())

{echo "Wystąpiła nieziemska lipa w połeczeniu z bazą - przegrałeś partie z sztuczną inteligencją";}

$wynik = mysqli_query($baza,"select * from pwrc5grv_cf7dbplugin_submits where field_name='email' and submit_time in (select submit_time from pwrc5grv_cf7dbplugin_submits where field_name='newsletterAgree' and field_value='Zapisz mnie do newslettera');");

while($row = $wynik->fetch_array()) {
	$dater = $row['submit_time'];
	$calendar = date('Y-m-d H:i:s',$dater);
	$exploder = substr($dater,0,-5);
	$interval=60*6;
	$period=time();
	if($period - $exploder <= $interval) {
		file_get_contents ('http://new.orpik.pl/a/217/1383/add.html?utm_source=skinmate.pl&utm_medium=skrypt_z_crona&email='.$row['field_value']);	
	} 
}

mysqli_close($baza);
?>