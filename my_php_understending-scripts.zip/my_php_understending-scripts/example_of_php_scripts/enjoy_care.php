
<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		

		table {
			margin-top: 50px;
		border:2px solid #B82457 ;
		line-height: 30px;
	}


	table th {
		line-height: 50px !important;

	}


	.rower {
		height: 100px;
		word-break: break-all;
		font-size: 13px;
		text-align: center;


	}

	.rower td {
					line-height: 20px;
					border-top: 2px dotted black;

	}



	.colorus {
 		color:red;
 		display: block;
 	}

    .link {
 		color: 	#8B0000;
 		text-align: center;
 		width: 10%;
 	}

 	.dater {
 	text-align: center;
	color:black;
	}

	.haszer {
 		color: 	#4682B4;
 		text-align: center;
 		width: 40%;
 	}

 	.idder {
 		text-align: center;
 		width: 5%;
 		height: 50%;
 	}

	.zdjecie {

		text-align: center;
	}

	.header  {
	
		height: 70px;


	}



	.spamer {
				position: fixed;

		height: 100px;
		width: 50px;
		position: absolute;
	border: 1px solid black;

	}
	/* #image {
 		 border-top: none;
  	}

 	#order {
 		border-top:2px dashed black;
 		text-align: center;
 	}


 	

#imager {
	border:none;

}


#dater {
	color:goldenrod;
}
*/
		</style>

  

</head>
<body>


<!-- <div class='spamer'>dasds</div>
 -->
</body>




<?php



 $data=array();
 exec('cat /web/vs/adam/app/enjoycare_1.log | cut -d " " -f 3- | sort | uniq', $data);
  
// var_dump($data);

 echo "<table><th class='header'><tr><td class='idder'><font color='red'>ID</font></td><td class='link'>LINK DO INSTAGRAMA:</td><td class='zdjecie'>ZDJĘCIE</td><td class='haszer'>HASZTAG</td><td class='dater'>DATA DODANIA POSTA</td></tr>
<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
	 	</tr>
	 	<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
	 	</tr>
 </th>";
 $counter = 1;
 $i=0;
 $contener=array();
 foreach($data as $line) {
 	$l=explode("|",$line);
 	$urlId=$l[0];
 	$dater=$l[1];
 	$hasz=$l[2];
 	$src=$l[4];
 	//$conteiner=array_unique($hasz);
 	//$conteiner = array_filter($hasz);
	//$conteiner = array_values($hasz);
 	//var_dump($conteiner);
 	if ($urlId !== "" && !in_array($urlId,$contener)) {
	    echo '
	 	<tr class="rower"><td><font color="green"><b>'.$counter.'</b></font></td>
	 	<td style="height:50px"><a href="https://www.instagram.com/p/'.$urlId.'/">"https://www.instagram.com/p/'.$urlId.'/"</a></td>
	 			<td><span> <a href="'.$src.'" target="_blank" alt="Ten użytkownik sie nie liczy"><img width="150" src="'.$src.'"></a></span></td>
	 	<td><p><font style="color: 	#000080">'.$hasz.'</font></p></td>
	 	
	 	<td><font style="color:green">'.date('Y-m-d H:i:s',$dater).'</font></td></tr>';
	 	$counter++;
	 	$contener[]=$urlId;
	 }

 }
echo "</table>";

$brakujace=["BH8COgjD0wN", "BH7hyhtggVH", "BH7eSOmDAms", "BH4tVmigfO_", "BH4VyO0gv9T", "BHuXBj_gsU8", "BHsJ8jCDmk8", "BHg0sh8jSEw", "BGbc9E9q7cu", "BGO-_mZN-l_", "BFwfzzTPvn0", "BDUHHZTIYR1", "960TTMldAs", "uTRrkZDBcm", "p7Pt20jpnT"];

echo '<br><br>-----------------BRAKUJĄCE W NASZYM LOGU:-------------------------';

 echo "<table><th class='header'><tr><td class='idder'><font color='red'>ID</font></td><td class='link'>LINK DO INSTAGRAMA:</td><td class='zdjecie'>ZDJĘCIE</td><td class='haszer'>HASZTAG</td><td class='dater'>DATA DODANIA POSTA</td></tr>
<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
	 	</tr>
	 	<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
	 	</tr>
 </th>";
 $counter = 1;
 $i=0;
 foreach($brakujace as $line) {

	    echo '
	 	<tr class="rower"><td><font color="green"><b>'.$counter.'</b></font></td>
	 	<td style="height:50px"><a href="https://www.instagram.com/p/'.$line.'/">"https://www.instagram.com/p/'.$line.'/"</a></td>
	 			<td><span> <a href="" target="_blank" alt="Ten użytkownik sie nie liczy"><img width="150" src=""></a></span></td>
	 	<td><p><font style="color: 	#000080"></font></p></td>
	 	
	 	<td><font style="color:green"></font></td></tr>';
	 	$counter++;
	 

 }
echo "</table>";


?>
</html>
