<?php
// echo 111;
/*
- wczytanie pliku read, file_get_c...
- petla po wierszach while
- rozbicie po czymś - explode
*/

// //////////////////////////////////
// $arr_file = file('usunieto_instagram.log');


// foreach($arr_file as $line)
// {
//     echo($line);
// }


// $boom = explode("-------------------", $arr_file);


//////////////////////////////////////////


function boom (){
$handle = fopen("usunieto_instagram.log", "r");
$newData ='';
if ($handle) {
    while (($line = fgets($handle)) !== false) {
    	echo "\n\n------------------";
    	echo $line;
    	echo "------------------\n\n";
        // process the line read.\
        $atom = explode("=>",$line); 
        $id= trim(explode("[",$atom[1])[0]);
        $type= trim(explode("[",$atom[3])[0]);
        $s_id= trim(explode("[",$atom[5])[0]);
        $s_timestamp= trim(explode("[",$atom[7])[0]);
        $user_name= trim(explode("[",$atom[9])[0]);
        $user_screenname= trim(explode("[",$atom[11])[0]);
        $user_image= trim(explode("[",$atom[13])[0]);
        $title= trim(explode("[",$atom[15])[0]);
        $text= trim(explode("[",$atom[17])[0]);
        $image= trim(explode("[",$atom[19])[0]);
        $video= trim(explode("[",$atom[21])[0]);
        $correct= trim(explode("[",$atom[23])[0]);
        $data_saved= trim(explode("[",$atom[25])[0]);
        $likes= trim(explode("[",$atom[27])[0]);

        $sql="INSERT into gallery (id,type,s_id,s_timestamp,user_name,user_screenname,user_image,title,text,image,video,correct,data_saved,likes) VALUES (".$id.",'".addslashes($type)."','".addslashes($s_id)."',".$s_timestamp.",'".addslashes($user_name)."','".addslashes($user_screenname)."','".addslashes($user_image)."','".addslashes($title)."','".addslashes($text)."','".addslashes($image)."','".addslashes($video)."','".addslashes($correct)."','".addslashes($data_saved)."','".addslashes($likes)."');
";
        //echo $type;
    	print_r ($sql);
    	//echo $atom[0];
        // break;
      $newData .= $sql;     
    } 

    fclose($handle);

    ////////ZAPISANIE WYGŁADZONYCH DANYCH//////////

    //$file_open = fopen("/home/maciej/Pulpit/reservedforme/przywrocony_instagram.txt", "w");


	file_put_contents("przywrocony_instagram.txt", $newData);

	


} 
// else {
//       echo "Twoj wlasny generator noticow,errorow,fatal errow dziala wysmienicie";
//       } 
      

}

boom();


// $fp = fopen("usunieto_instagram.log", "r");
// $fr = fread($fp, 1000);




// for ($i = 0; $x <=10; $x++) {
// 	echo "numer $x <br>";

// }



?>