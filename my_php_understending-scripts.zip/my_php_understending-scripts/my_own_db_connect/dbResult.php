 <!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
<meta http-equiv="Content-type" content="text/html; charset=ISO-8859-2" />

	<style type="text/css">
	body {
		background-color: black;
		color:white;
	}

	.hrefer {
        margin: 0 auto;
        display: block;
        text-align: center;
        text-decoration:none;
        color:#CC333F;
        font-family: fantasy;
        font-size: 25px;
      }

      .hrefer:hover {
        text-shadow: 2px 2px whitesmoke;
      }


      .remover {
        margin: 0 auto;
        display: block; 
        position: relative;     

      }

    table, tr, td {
      border:1px solid white;
      text-align: center;
    }

    
    .holder {
    	text-align: center;
    	float: left;
    	position:relative;
    	width: 30px;
    	height: 20px;
    	border:1px solid red;
    }

    .td_name {
    	width: 120px;
    }

    .td_surname {
    	width: 100px;
    }

    .td_img {
    	height: 70px;	
    	width: 50px;
    }

	</style>
</head>
<body>

<div class="db_tester">
    <form method="post" action="#">

          <input name="show" type="submit" value="Pokaż baze"/>

    </form>
</div>





<?php

//file save function() - debug


function faceErrorPalm (){
    $fp = fopen("debugCode.txt", "r") or die ('</br>Unable to open file!');
; 

   $count = fread($fp, 1024); 

   fclose($fp); 

   $count = $count + 1; 

  echo "<p>Odwiedziny na stronie: " . $count . "</p>"; 

  $fp = fopen("debugCode.txt", "w"); 

  fwrite($fp, $count); 

     fclose($fp);

}

		faceErrorPalm();

///end debug



$name=$_POST['show'];
if(isset($_POST['show'])) {


$servername = "";
$username = "root";
$password = "";
$dbname = "prediction2016";

// Create connection
$baza = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($baza->connect_error) {
    die("Błąd połączenai: " . $baza->connect_error);
}
echo "Połączono pomyślnie";





mysqli_select_db('prediction2016');

	// zdefiniowanei zapytania
$takeDate = "select * from testy_dojlido";

$dataFacePalm = mysqli_query($baza, $takeDate);

// echo $dataFacePalm;

if(! $takeDate )
{
  die('</br></br>Nie było możliwosći pobrania danych: ' . mysqli_error());
}
echo "</br></br>Pobrano dane z bazy danych\n</br>";

// echo $takeDate;





//wyechowaie tabeli prezentujacej wyniki + usuwanie wpisu
 echo "<table><th><tr><td class='td_name'>ID & Name</td><td class='td_surname'>Surname</td><td>Remove data</td><tr></th> 
";
	while($row = mysqli_fetch_array($dataFacePalm)){
	echo "<tr><td><span class='holder'>" .$row['id']."&nbsp;&nbsp;&nbsp;</span>".$row['name'] . "</td><td>" . $row['surname'] ."<td><form method='get' action='#'><a style='text-decoration:none;color:orange;' href='#'><button name='removeMe'>Remove</button></a></td>" .'<td><input type="checkbox" name="checkboxer" value='.$row["id"].' style="width:30px;text-align:center;border"></input ><input style="display:none;" value='.$row["id"].' name="helper"></input></td>'.'<td class="td_img">'.$row['img_name'].'</td>'."</td></tr></form>"; 

		}




//jezeli wybrano przycisk usuń rekord
if(isset($_GET['removeMe']) && isset($_GET['checkboxer'])) {
 	$helper = $_GET['helper'];
 	$boxer = $_GET['checkboxer'];
 		


 $sql_remove = "DELETE FROM testy_dojlido WHERE id='$helper'";
		 $dataRemoveFacePalm = mysqli_query($baza,$sql_remove);
		
//end dla usun rekord



// kod odpowiedzialny za order BY primary-key auto-incrementation				

$query_one = "SET  @num := 0;";  			 
$query_one .= "UPDATE testy_dojlido SET id = @num := (@num+1);"; 
$query_one .= "ALTER TABLE testy_dojlido AUTO_INCREMENT =1";

/* execute multi query */
if (mysqli_multi_query($baza, $query_one)) {
	echo '';
} else {echo '</br></br>Lipa poleciał error nie bylo auto-increment';}
		

  	//jezeli nie zaznaczono check boxa przy rekordzie do usuniecia
 } elseif (empty($_GET['checkboxer'])) {
 	echo '<p style="color:red;font-size:15px">*Aby usunąc rekord należy zaznaczyć checkbox (kwadracik) przy właściwej pozycji i nacisnac przycisk <b>Remove.</b> </p>';
 	
 }

//domkniecie echowanej tabeli prezentującej wpisy w DB
echo "</br></br></table>";


}				





mysqli_close($baza);





?>





</body>
</html> 