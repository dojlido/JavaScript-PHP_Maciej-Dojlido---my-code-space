<!DOCTYPE html>
<html>
	<head>
	
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
	<script src="http://thecodeplayer.com/uploads/js/prefixfree.js" type="text/javascript"></script>
			
			<style type="text/css">
			body {
				background-color: black;
				color:white;
			}

      .hrefer {
        margin: 0 auto;
        display: block;
        text-align: center;
        text-decoration:none;
        color:#CC333F;
        font-family: fantasy;
        font-size: 25px;
      }

      .hrefer:hover {
        text-shadow: 2px 2px whitesmoke;
      }


      .remover {
        margin: 0 auto;
        display: block; 
        position: relative;     

      }

    table, tr, td {
      border:1px solid white;
      text-align: center;
    }

    .holder {
    	float: left;
    	position:relative;
    	width: 30px;
    	height: 20px;
    	border:1px solid red;
    }

    .namer {
    }

			</style>

<script type="text/javascript">
	$(document).ready(function(){
  
   $(function() {
    $('#name, #surname').keydown(function(e) {
      if (e.shiftKey || e.ctrlKey || e.altKey) {
        e.preventDefault();
        alert("ale lipa");
      } else {
        var key = e.keyCode;
        if (!((key == 8) || (key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90))) {
          e.preventDefault();
        }
      }
    });
  });

});



</script>




	</head>
<body>


<?php

//jezeli button klikniety
if(isset($_POST['add']))
{


$name=$_POST['name'];
$surname=$_POST['surname'];
$binary=file_get_contents($_FILES['image']['tmp_name']);



if (empty($_POST["name"])) {
    $warn_1 = "Name is required";
    echo "<h3 style='color:red;text-align:center'>$warn_1</h3>
   
    
    <div class='db_tester'>
    <form method='post' action='http://typer.zjed.pl/test/dbConnect.php'>

      <label>First Name</label>
        <input type='text' name='name' value='' />

            <br />

      <label>Last Name</label>
        <input type='text' name='surname' />

            <br />
            <br />
          <input name='add' type='submit' value='Add Something that HULA'>
    </form>
</div>";

    return $warn_1;
}
  		  // walidacja dla znakow specjalnych i cyfr

      if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
  	      $warn_2 = "Only letters and white space are allowed";
          echo "<h3 style='color:red;text-align:center'>$warn_2</h3>
 
    
<div class='db_tester'>
    <form method='post' action='http://typer.zjed.pl/test/dbConnect.php'>

      <label>First Name</label>
        <input type='text' name='name' value='' />

            <br />

      <label>Last Name</label>
        <input type='text' name='surname' />

            <br />
            <br />
          <input name='add' type='submit' value='Add Something that HULA'>
    </form>
</div>";
            
            return $warn_2;
     
  	    }
  
  if (empty($_POST["surname"])) {
    $warn_3 = "Surname is required";
    echo "<h3 style='color:red;text-align:center'>$warn_3</h3>
   
    
    <div class='db_tester'>
    <form method='post' action='http://typer.zjed.pl/test/dbConnect.php'>

      <label>First Name</label>
        <input type='text' name='name' value='' />

            <br />

      <label>Last Name</label>
        <input type='text' name='surname' />

            <br />
            <br />
          <input name='add' type='submit' value='Add Something that HULA'>
    </form>
</div>";

    return $warn_3;
}
        // walidacja dla znakow specjalnych i cyfr

      if (!preg_match("/^[a-zA-Z ]*$/",$surname)) {
          $warn_4 = "Only letters and white space are allowed in surname";
          echo "<h3 style='color:red;text-align:center'>$warn_4</h3>
 
    
<div class='db_tester'>
    <form method='post' action='http://typer.zjed.pl/test/dbConnect.php'>

      <label>First Name</label>
        <input type='text' name='name' value='' />

            <br />

      <label>Last Name</label>
        <input type='text' name='surname' />

            <br />
            <br />
          <input name='add' type='submit' value='Add Something that HULA'>
    </form>
</div>";
            
            return $warn_4;
     
        }


////////Koniec validacji///////////




	$servername = "";
    $username = "root";
    $password = "";
    $dbname = "prediction2016";

$baza=mysql_connect("", "root" ,"haslo", "prediction2016");

if (!$baza) {
    die("<h2 style=''>Lipa konkretna połączenie zmarło: </h2>" . mysql_error());
}
echo "<p style='' >Connected successfully</p>";



///walidacja dla $name i $surname
// $select = "SELECT * FROM testy_dojlido WHERE name='$name'";

// $queryFay = mysql_query($baza,$select);

// if(mysql_num_rows($queryFay) == 0) {
// 	echo "imei istnieje";
// }

// $queryTest = mysql_query($baza, "SELECT * FROM testy_dojlido WHERE name ='".$name."'");
// if(mysql_num_rows($queryTest) > 0){

//     echo "tyryrys already exists";
// }

// $queryTest = "SELECT `name` FROM `testy_dojlido` WHERE name=?";


// $resulted = mysql_query("SELECT * FROM testy_dojlido WHERE name ='".$name."'");

// $num_rows = mysql_num_rows($resulted);

// if ($num_rows > 0) {
//    echo " not tyryrys already exists";
// }
// else {
// echo "tyryrys already exists";

// }





// $sql = "INSERT INTO testy_dojlido (name,surname) VALUES ('$name','$surname') WHERE NOT EXISTS (SELECT FROM testy_dojlido where name='$name' and surname='$surname')";


$finfo = new finfo(FILEINFO_MIME);
$type = $finfo->file($_FILES['image'],['tmp_name']);
$mime = substr($type, 0, strpos($type, ';'));

$sql = "INSERT INTO `testy_dojlido` (`name`,`surname`,`data`,`mime`,`img_name`) VALUES('".mysql_real_escape_string($name)."','".mysql_real_escape_string($surname)."','".mysql_real_escape_string($binary)."','".mysql_real_escape_string($mime)."','".mysql_real_escape_string($_FILES['image']['name'])."')";





// // wepchnij do tabeli
// $sql = "INSERT INTO testy_dojlido ".
//        "(name, surname, picture) ".
//        "VALUES ".
//        "('".mysql_real_escape_string($name)."','".mysql_real_escape_string($surname)."','".mysql_real_escape_string($picture)."')";// wywolanei zmiennych odebranych z formularza

mysql_select_db('prediction2016');
//spiecie z baza poprzez wywolanie mziennych mysql_conect oraz zapytania insert into
$retval = mysql_query( $sql, $baza );


if(! $retval )
{
  die('Could not enter data: ' . mysql_error());
}
else { echo "Entered data successfully\n";
	echo '<a href="http://typer.zjed.pl/test/dbResult.php"><button style="background-color:green;display:block;margin:0 auto;">Podgląd bazy</button></a>'; 
}




// // $wynik = mysqli_query($baza,"select * from 





mysql_close($baza);

} 
else
{
?>
<div class="db_tester">
    <form method="post" enctype="multipart/form-data" action="<?php $_PHP_SELF ?>">

      <label>First Name</label>
        <input type="text" id="name" name="name" />

            </br>
            </br>

      <label>Last Name</label>
        <input type="text" id="surname" name="surname" />

        	</br>
        	</br>

     <fieldset>
        <input placeholder="Dodaj obrazek" type="file" name="image"  />
    </fieldset>

            <br />
            <br />
          <input name="add" type="submit" value="Add Something that HULA">
    </form>
</div>
<?php
}
?>







</body>
</html>
